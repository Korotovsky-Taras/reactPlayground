import React, {Component} from 'react';
import CardList from './components/cards/cardlist';
import Header from './components/header/header';
import Footer from './components/footer/footer';
import './App.css';

class App extends Component {
	render() {
		return (
			<div className="app-wrapper">
				<Header/>
				{/*<Sidebar />*/}
				<div className="app-wrapper__inner">
					<div className="app-container">
						<CardList/>
					</div>
				</div>
				<Footer/>
			</div>
		);
	}
}

export default App;

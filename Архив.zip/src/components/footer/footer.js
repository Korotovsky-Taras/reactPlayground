import React, { Component } from 'react';
import './footer.css';

export default class extends Component {
	render(){
		return (
			<div className="app-footer">
				<div className="app-container">
					<img src="" alt="" />
				</div>
			</div>
		);
	}
}
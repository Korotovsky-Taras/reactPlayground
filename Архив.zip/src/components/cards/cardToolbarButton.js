import React, { Component } from 'react';
import './cardToolbarButton.css';

export default class extends Component {
	render() {
		return (
			<button className={this.props.className} onClick={this.props.onClickHandler}>
				{this.props.children}
			</button>
		);
	}
}
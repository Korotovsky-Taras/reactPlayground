import React, { Component } from 'react';
import Card from './card';
import './cardlist.css';

export default class extends Component {
	constructor(props){
		super(props);
		this.state = {
			data: []
		}
	}

	componentWillMount(...ar){
		console.log("componentWillMount", ar);
	}

	componentDidMount(...ar){
		console.log("componentDidMount", ar);
		fetch('https://jsonplaceholder.typicode.com/posts')
				.then(response => response.json())
				.then(json => {
					this.setState((prevState, props) => {
						return {
							...prevState,
							data: json.map(el => {
								el.image = "https://picsum.photos/200/200/?image=" + el.id;
								return el;
							})
						};
					})
				})
	}

	shouldComponentUpdate(...ar){
		// console.log("shouldComponentUpdate", ar);
		return true;
	}

	componentWillUpdate(...ar){
		// console.log("componentWillUpdate", ar);
	}

	componentDidUpdate(...ar){
		// console.log("componentDidUpdate", ar);
	}

	componentWillReceiveProps(...ar){
		// console.log("componentWillReceiveProps", ar);
	}

	render() {
		return (
			<div className="app-card-list">
				{this.state.data.map((itemData) => {
					return <Card key={itemData.id}
								 data={itemData}
								 index={itemData.id}
								 onRemove={this.onRemove}
								 onLiked={this.onLiked} />;
				})}
			</div>
		);
	}

	onRemove = (index) => {
		this.setState((prevState, props) => {
			return {
				...prevState,
				data: prevState.data.filter(el => {
					return el.id !== index;
				})
			};
		})
	};

	onLiked = (index, count) => {
		this.setState((prevState, props) => {
			return {
				...prevState,
				data: prevState.data.map((el) => {
					el.liked = false;
					el.likeCount = 0;
					if(!el.liked && el.id === index) {
						el.likeCount = count;
						el.liked = true;
					}
					return el;
				})
			};
		})
	}
}